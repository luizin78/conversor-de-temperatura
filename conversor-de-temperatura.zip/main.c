#include <stdio.h>

int main() {

    int opcao;
    double temperatura, resultado;

    printf("=============CONVERSOR DE TEMPERATURA=======================\n");
    

    printf("\nEscolha uma opcao:\n");

    printf("\n--- CELSIUS ---\n");
    printf("1 - Celsius para Fahrenheit\n");
    printf("2 - Celsius para Kelvin\n");

    printf("\n--- FAHRENHEIT ---\n");
    printf("3 - Fahrenheit para Celsius\n");
    printf("4 - Fahrenheit para Kelvin\n");

    printf("\n--- KELVIN ---\n");
    printf("5 - Kelvin para Celsius\n");
    printf("6 - Kelvin para Fahrenheit\n");

    printf("\nDigite sua opcao: ");
    scanf("%d", &opcao);

    printf("\nDigite a temperatura: ");
    scanf("%lf", &temperatura);

    switch (opcao) {

        case 1:
            // Celsius para Fahrenheit
            resultado = (temperatura * 9 / 5) + 32;

            printf("\nResultado: %.2f °F\n", resultado);
            break;

        case 2:
            // Celsius para Kelvin
            resultado = temperatura + 273.15;

            printf("\nResultado: %.2f K\n", resultado);
            break;

        case 3:
            // Fahrenheit para Celsius
            resultado = (temperatura - 32) * 5 / 9;

            printf("\nResultado: %.2f °C\n", resultado);
            break;

        case 4:
            // Fahrenheit para Kelvin
            resultado = (temperatura - 32) * 5 / 9 + 273.15;

            printf("\nResultado: %.2f K\n", resultado);
            break;

        case 5:
            // Kelvin para Celsius
            resultado = temperatura - 273.15;

            printf("\nResultado: %.2f °C\n", resultado);
            break;

        case 6:
            // Kelvin para Fahrenheit
            resultado = (temperatura - 273.15) * 9 / 5 + 32;

            printf("\nResultado: %.2f °F\n", resultado);
            break;

        default:
            printf("\nOpcao invalida!\n");
    }

    printf("\n=============FIM DO PROGRAMA=======================\n");
   
   

    return 0;
}

